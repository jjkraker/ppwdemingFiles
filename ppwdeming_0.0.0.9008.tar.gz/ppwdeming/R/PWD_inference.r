#' Weighted Deming Regression -- Inference
#' @name PWD_inference
#'
#' @description
#' This routine fits the regression, uses the jackknife to get its precision, and optionally prints it out.
#'
#' @usage
#' PWD_inference(X, Y, lambda=1, MDL=NA, epsilon=1e-8, printem=FALSE)
#'
#' @param X		the vector of predicate readings,
#' @param Y		the vector of test readings,
#' @param lambda		*optional* the ratio of the X to the Y precision profile (defaults to 1),
#' @param MDL		*optional* medical decision level(s),
#' @param epsilon		*optional* convergence tolerance limit,
#' @param printem	  *optional* - if TRUE, routine will print out results.
#'
#' @details
#' *This could be added upon literature review.*
#'
#' @returns A list containing the following components:
#'
#'   \item{alpha }{the fitted intercept}
#'   \item{beta }{the fitted slope}
#'   \item{fity }{the vector of predicted Y}
#'   \item{mu }{the vector of estimated latent true values}
#'   \item{resi }{the vector of residuals}
#'   \item{preresi }{the vector of leave-one-out predicted residuals}
#'   \item{sigma }{the estimate of the Rocke-Lorenzato \eqn{\sigma}}
#'   \item{kappa }{the estimate of the Rocke-Lorenzato \eqn{\kappa}}
#'   \item{like }{the -2 log likelihood L}
#'   \item{sealpha }{the jackknife standard error of alpha}
#'   \item{sebeta }{the jackknife standard error of beta}
#'   \item{covar }{the jackknife covariance between alpha and beta}
#'   \item{preMDL }{the predictions at the MDL(s)}
#'   \item{preMDLl }{the lower confidence limit(s) of preMDL}
#'   \item{preMDLu }{the upper confidence limit(s) of preMDL}
#'
#' @author Douglas M. Hawkins
#'
#' @note *further notes*
#'
#' @references   *Presumably a reference for Rocke-Lorenzato with unknown sigma, kappa goes here.*
#'
#' @export

PWD_inference <- function(X, Y, lambda=1, MDL=NA, epsilon=1e-8, printem=FALSE) {

  n <- length(X)
  pseudalpha <- NULL
  pseudbeta  <- NULL
  preresi    <- NULL
  for (dele in 0:n) {
    x  <- X
    y  <- Y
    if (dele > 0) {
      x   <- X[-dele]
      y   <- Y[-dele]
    }

    do <- PWD_get_gh(x, y, lambda, epsilon)
    if (dele == 0) {
      fullalpha  <- do$alpha
      fullbeta   <- do$beta
      mu         <- do$mu
      resi       <- do$resi
      fity       <- do$fity
      sigma      <- do$sigma
      kappa      <- do$kappa
      like       <- do$like
    } else {
      subalpha   <- do$alpha
      subbeta    <- do$beta
      pseudalpha <- c(pseudalpha, n*fullalpha - (n-1)*subalpha)
      pseudbeta  <- c(pseudbeta , n*fullbeta  - (n-1)*subbeta )
      preresi    <- c(preresi, Y[dele]-subalpha-subbeta*X[dele])
    }
  }
  alpha   <- fullalpha
  beta    <- fullbeta
  sealpha <- sd(pseudalpha) / sqrt(n)
  sebeta  <- sd(pseudbeta ) / sqrt(n)
  covar   <- sealpha * sebeta * cor(pseudalpha,pseudbeta)
  tcut <- qt(0.975, n-1)
  nMDL    <- 0
  preMDL  <- NA
  preMDLl <- NA
  preMDLu <- NA
  if (!is.na(sum(MDL))) {
    nMDL    <- length(MDL)
    preMDL  <- alpha + beta*MDL
    MoEpre  <- tcut*sqrt(sealpha^2 + (sebeta*MDL)^2 + 2*covar*MDL)
    preMDLl <- preMDL - MoEpre
    preMDLu	<- preMDL + MoEpre
    #	print(data.frame(preMDL, preMDLl, preMDLu))
  }
  if (printem) {
    cat(sprintf("%9s %8s %8s %9s\n", "Parameter", "estimate", "se", "CI"))
    CI   <- fullalpha + tcut * sealpha * c(-1,1)
    cat(sprintf("Intercept %8.3f %8.3f (%7.3f, %6.3f)\n", fullalpha, sealpha, CI[1], CI[2]))
    CI   <- fullbeta + tcut * sebeta * c(-1,1)
    cat(sprintf("slope     %8.3f %8.3f (%7.3f, %6.3f)\n", fullbeta , sebeta, CI[1], CI[2]))
    cat(sprintf("\nsigma %6.4f kappa %6.4f -2 log likelihood %7.3f\n", sigma, kappa, like))
    if (nMDL > 0) {
      for (kk in 1:nMDL) {
        cat(sprintf("MDL %7.3f prediction %7.3f CI %7.3f %7.3f\n",
                    MDL[kk], preMDL[kk], preMDLl[kk], preMDLu[kk]))
      }
    }
  }

  return(list(alpha=fullalpha, beta=fullbeta, fity=fity, mu=mu, resi=resi, preresi=preresi,
              sigma=sigma, kappa=kappa, like=like, sealpha=sealpha, sebeta=sebeta, covar=covar,
              preMDL=preMDL, preMDLl=preMDLl, preMDLu=preMDLu))
}
