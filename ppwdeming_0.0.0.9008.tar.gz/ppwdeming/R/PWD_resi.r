#' Fit Rocke-Lorenzato profile model to residuals
#' @name PWD_resi
#'
#' @description
#' This routine fits the Rocke-Lorenzato precision profile model to the residuals from the fit.
#'
#' @usage
#' PWD_resi(true, resi, epsilon=1e-5, printem=FALSE)
#'
#' @param true  	the vector of values used to predict the precision – commonly X,
#' @param resi		the vector of residuals whose variance is thought to be a function of “true”,
#' @param epsilon		*optional* convergence tolerance limit,
#' @param printem	  *optional* - if TRUE, routine will print out results.
#'
#' @details
#' *This could be added upon literature review.*  The Rocke-Lorenzato precision profile model is \deqn{SD^2 = \sigma_r^2 + (\kappa_r\cdot true)^2}
#'
#' @returns A list containing the following components:
#'
#'   \item{sigmar}{the estimate of \eqn{\sigma_r}}
#'   \item{kappar}{the estimate of \eqn{\kappa_r}}
#'   \item{like}{the likelihood}
#'   \item{scalr}{the scaled residuals}
#'   \item{poolsig}{the maximum likelihood estimate of \eqn{\sigma_r} if \eqn{\kappa_r} =0}
#'   \item{poolkap}{the maximum likelihood estimate of \eqn{\kappa_r} if \eqn{\sigma_r} =0}
#'   \item{tests}{the chi-squared test statistics for \eqn{\kappa_r}=0 and for \eqn{\sigma_r}=0}
#'   \item{Pvals}{the P values for these two tests.}
#'
#' @author Douglas M. Hawkins
#'
#' @note *further notes*
#'
#' @examples #mini-example with created data.
#'
#' @references   *Presumably a reference for Rocke-Lorenzato with unknown sigma, kappa goes here.*
#'
#' @importFrom stats optimize pchisq shapiro.test
#'
#' @export

PWD_resi    <- function(true, resi, epsilon=1e-5, printem=FALSE) {
  n       <- length(true)
  absres  <- abs(resi)
  key     <- order(true)
  sortres <- round(absres[key],4)
  sorttru <- true  [key]
  vars    <- sortres^2
  cvsq    <- (sortres/sorttru)^2
  logcv   <- round(0.5 * log(cvsq),4)
  lowr    <- 1:round(n/3)
  hir     <- round(2*n/3):n
  maxsig  <- max(sortres[lowr])
  maxkap  <- 0.5*max(abs(logcv[hir]), na.rm=TRUE)

  innr     <- function(kap, sig) {
    modl   <- sig^2 + (kap*sorttru)^2
    sum((vars / modl + log(modl)))
  }

  a       <- 0
  b       <- maxsig
  gr      <- 1.618
  dif     <- b-a
  h       <- maxsig
  while (h > epsilon) {
    h  <- b - a
    c  <- b - h / gr
    d  <- a + h / gr
    vc <- optimize(innr, c(0,maxkap), c)
    fc <- vc$objective
    vd <- optimize(innr, c(0,maxkap), d)
    fd <- vd$objective
    if (fc < fd) {
      b <- d
    } else {
      a <- c
    }
  }
  sigma <- c
  kappa <- vc$minimum
  like  <- fc
  if (fd < fc) {
    sigma <- d
    kappa <- vd$minimum
    like  <- fd
  }

  profl   <- sqrt(sigma^2 + (kappa*true)^2)
  scalr   <- resi/profl

  proflf  <- sqrt(sigma^2 + (kappa*sorttru)^2)

  poolsig <- sqrt(mean(vars))
  poolkap <- sqrt(mean(cvsq))
  consdl  <- innr(0, poolsig)
  concvl  <- innr(poolkap, 0)
  check   <- innr(vc$minimum, c)
  tests   <- c(consdl, concvl) - fc
  Pvals   <- pchisq(tests, 1, lower.tail=FALSE)
  if (printem) {
    SW    <- shapiro.test(scalr)$p.value
    cat(sprintf("Rocke-Lorenzato fit to residuals\nsigma %6.4f kappa %6.4f\n", sigma, kappa))
    cat(sprintf("P values for constant sd %6.4f cv %6.4f normality %6.4f\n", Pvals[1], Pvals[2], SW))
  }

  return(list(sigmar=sigma, kappar=kappa, like=like, scalr=scalr, poolsig=poolsig, poolkap=poolkap, tests=tests, Pvals=Pvals))
}
