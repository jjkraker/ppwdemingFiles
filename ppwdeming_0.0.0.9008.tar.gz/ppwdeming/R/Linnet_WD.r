#' Linnet proportional CV weighted Deming
#' @name Linnet_WD
#'
#' @description
#' This routine, provided for convenience, makes Linnet’s constant CV fit.
#'
#' @usage
#' Linnet_WD(XX, YY, lambda=1, MDL=NA, getCI=TRUE, epsilon=1e-9, printem=FALSE)
#'
#' @param XX		the vector of predicate readings,
#' @param YY		the vector of test readings,
#' @param lambda		ratio of g function to h function,
#' @param MDL		optional medical decision limit(s),
#' @param getCI		if TRUE, generates jackknife standard errors,
#' @param epsilon		optional tolerance limit,
#' @param printem	if TRUE, prints results.
#'
#' @details
#' *This could be added upon literature review.*
#'
#' @returns A list containing the following components:
#'
#'   \item{alpha }{the fitted intercept}
#'   \item{beta }{the fitted slope}
#'   \item{sealpha }{the jackknife standard error of alpha}
#'   \item{sebeta }{the jackknife standard error of beta}
#'   \item{covar }{the jackknife covariance between alpha and beta}
#'   \item{preMDL }{the predictions at the MDL(s)}
#'   \item{preMDLl }{the lower confidence limit(s) of preMDL}
#'   \item{preMDLu }{the upper confidence limit(s) of preMDL}
#'
#' @author Douglas M. Hawkins
#'
#' @note *further notes*
#'
#' @examples #mini-example with created data.
#' @references   *Presumably one of the Linnet references goes here.*
#'
#' @importFrom stats cor qt sd
#' @export

Linnet_WD <- function(XX, YY, lambda=1, MDL=NA, getCI=TRUE, epsilon=1e-9, printem=FALSE) {
  pseuda <- NULL
  pseudb <- NULL
  n      <- length(X)
  top    <- n
  if (!getCI) top <- 0
  for (dele in 0:top) {
    x <- XX
    y <- YY
    if (dele > 0) {
      x <- XX[-dele]
      y <- YY[-dele]
    }
    X   <- x
    Y   <- y
    diff <- 2*epsilon
    while (diff > epsilon) {
      w    <- ((x+y)/2)^(-2)
      sumw <- sum(w)
      xbar <- sum(w*x)/sumw
      ybar <- sum(w*y)/sumw
      uw   <- sum(w*(x-xbar)^2)
      qw   <- sum(w*(y-ybar)^2)
      pw   <- sum(w*(x-xbar)*(y-ybar))
      surd <- (uw - lambda*qw)^2 + 4*lambda*pw^2
      b    <- (lambda*qw - uw + sqrt(surd))/(2*lambda*pw)
      a    <- ybar - b * xbar
      d    <- y -a - b*x
      deno <- 1 + lambda * b^2
      oldX <- X
      oldY <- Y
      X    <- x + lambda * b * d / deno
      Y    <- y - d / deno
      diff <- sum((oldX-X)^2+(oldY-Y)^2) / sum(oldX^2+oldY^2)
    }
    if (dele == 0) {
      fulla <- a
      fullb <- b
    } else {
      pseuda <- c(pseuda, n*fulla - (n-1)*a)
      pseudb <- c(pseudb, n*fullb - (n-1)*b)
    }
  }
  alpha   <- fulla
  beta    <- fullb
  sealpha <- NA
  sebeta  <- NA
  covar   <- NA
  nMDL    <- 0
  preMDL  <- NA
  preMDLl <- NA
  preMDLu <- NA
  if (getCI) {
    sealpha <- sd(pseuda) / sqrt(n)
    sebeta  <- sd(pseudb) / sqrt(n)
    covar   <- sealpha * sebeta * cor(pseuda, pseudb)
  }
  if (!is.na(sum(MDL))) {
    nMDL    <- length(MDL)
    preMDL  <- alpha + beta*MDL
    MoEpre  <- tcut*sqrt(sealpha^2 + (sebeta*MDL)^2 + 2*covar*MDL)
    preMDLl <- preMDL - MoEpre
    preMDLu	<- preMDL + MoEpre
  }
  if (getCI & printem) {
    cat(sprintf("Linnet weighted Deming\n\testimate\tse\tCI\n"))
    tcut <- qt(0.975, n-1)
    CIa <- alpha + sealpha * c(-tcut, tcut)
    CIb <- beta  + sebeta  * c(-tcut, tcut)
    cat(sprintf("Intercept\t%3.3f\t%3.3f\t%3.3f\t%3.3f\n", alpha, sealpha, CIa[1], CIa[2]))
    cat(sprintf("Slope\t%3.3f\t%3.3f\t%3.3f\t%3.3f\n", beta, sebeta, CIb[1], CIb[2]))
  }
  return(list(alpha=alpha, beta=beta, sealpha=sealpha, sebeta=sebeta, covar=covar,
              preMDL=preMDL, preMDLl=preMDLl, preMDLu=preMDLu))
}
